% Ref: Jinshan Zeng, Wotao Yin and Ding-Xuan Zhou, Moreau envelope 
% augmented Lagrangian method for nonconvex optimization with linear
% constraints, Journal of Scientific Computing, 2021
% ADMM for the sparse regularized phase retrieval problem:
% min_x \sum_{i=1}^m |<ai,x>^2-bi|+c||x||_1, which is equivalent to
% min_{x,y} \sum_{i=1}^m |<ai,yi>^2-bi|+c||x||_1 s.t. x-yi=0, i=1,...,m
function [alg,staterr,recoverr] = ADMM_PR(PR,xtr,init,c,beta,NumIter)
% Inputs:
% PR: setting of problems (PR.A: linear vectors ai; PR.b: observed vector)
% xtr: true sparse signal
% c: regularization para
% beta: penalty para for augmented Lagrangian
% init: initialization (init.x, init.y, init.u, init.v, init.lamb)
% NumIter: number of iterations

% Outputs:
% alg.x: x; alg.y(j): yj; alg.u: u; alg.v(j):vj; alg.lamb: lambda
% staterr: stationary error = sqrt(beta^2*norm(A'B(y-y0))^2+norm(lamb-lamb0)^2/beta^2)
% recoverr: recovery error = norm(x-xtr)

staterr = zeros(NumIter,1);
recoverr = zeros(NumIter,1);
n = size(init(1).x,1); % dimension of vector
m = size(PR.b,1); % size of samples

for i=1:NumIter
    lamb_y = 0;
    % sum_{j=1}^m (lambdajk+beta*yjk)
    for j=1:m 
        lamb_y =  lamb_y + (init(j).lamb + beta*init(j).y);
    end
    clear j;
   alg(1).x = max(0,abs(lamb_y)-c).*sign(lamb_y)/(beta*m); % update x
   
   temp_diffy = zeros(n,1);
   temp_difflamb = zeros(n,1);
   for j=1:m 
      tempy = alg(1).x - init(j).lamb/beta;
      alg(j).y = Prox_pr(PR.A(:,j),PR.b(j),1/beta,tempy); % update y
      alg(j).lamb = init(j).lamb + beta*(alg(j).y-alg(1).x); % update lambda
      temp_diffy = temp_diffy + (init(j).y-alg(j).y); % yj(k) - yj(k+1)
      temp_difflamb = temp_difflamb + (alg(j).lamb - alg(j).lamb); 
      
      % recursive
      init(j).y = alg(j).y;
      init(j).lamb = alg(j).lamb;      
   end
   % recursive
   init(1).x = alg(1).x;
   
   staterr(i) = sqrt(beta^2*norm(temp_diffy)^2 + norm(temp_difflamb)^2/beta^2); % stationary error
   recoverr(i) = norm(alg(1).x-xtr); % recovery error
   fprintf('Iteration: %g, staterr: %g, recoverr: %g \n', i, staterr(i), recoverr(i));   
   
   clear j; clear tempy; clear temp_diffy; clear temp_difflamb;
end
clear i; clear init;
end