% Ref: Jinshan Zeng, Wotao Yin and Ding-Xuan Zhou, Moreau envelope 
% augmented Lagrangian method for nonconvex optimization with linear
% constraints, Journal of Scientific Computing, 2021
% show the effectiveness of MEAD for the following sparse regularized phase retrieval problem:
% min_x \sum_{i=1}^m |<ai,x>^2-bi|+c||x||_1 

clear all; close all; clc;
warning of all;
%% settings of the quadratic programming
m = 100;
n = 300;
k = 10; % sparsity of signal
PR.A = randn(n,m); % matrix of linear vectors (aj: n*1)
xtr = zeros(n,1);
tempI = randperm(n);
xtr(tempI(1:k)) = randn(k,1);
xtr(tempI(1:k)) = xtr(tempI(1:k))+ 0.2*sign(xtr(tempI(1:k)));
clear tempI;
% PR.b = ((PR.A)'*xtr).^2 + 1e-3*randn(m,1); % vector of observations bj = <aj,x>^2, j=1..,m
PR.b = ((PR.A)'*xtr).^2; % noiseless case
NumIter = 2e4; % number of iterations in the outer loop

%% MEAD 
init(1).x = xtr + 0.02*randn(n,1); % starting a good initial guess
init(1).u = init(1).x;
for j=1:m
   init(j).y = init(1).x;
   init(j).v = init(1).x;
   init(j).lamb = zeros(n,1);
end
clear j;
beta = 100; % penalty parameter in augmented Lagrangian
gamma = 1/2; % proximal parameter (gamma in (0,1/2/norm(q)^2))
c = 1e-1; % regularization parameter


eta1 = 0.5; % step size for z-step eta in (0,2) 
[alg_mead1,staterr_mead1,recoverr_mead1] = MEAD_PR(PR,xtr,init,c,beta,gamma,eta1,NumIter);

eta2 = 1; % step size for z-step eta in (0,2) 
[alg_mead2,staterr_mead2,recoverr_mead2] = MEAD_PR(PR,xtr,init,c,beta,gamma,eta2,NumIter);

eta3 = 1.5; % step size for z-step eta in (0,2) 
[alg_mead3,staterr_mead3,recoverr_mead3] = MEAD_PR(PR,xtr,init,c,beta,gamma,eta3,NumIter);

% run ADMM as the competitor
[alg_admm,staterr_admm,recoverr_admm] = ADMM_PR(PR,xtr,init,c,beta,NumIter);

% save staterr_mead1; save recoverr_mead1;
% save staterr_mead2; save recoverr_mead2;
% save staterr_mead3; save recoverr_mead3;
% save staterr_admm; save recoverr_admm;

Iter = (1:NumIter)';
% plot recovery error
figure(1),
semilogy(Iter(1:100:end),recoverr_admm(1:100:end),'m-','LineWidth',2);
hold on;
semilogy(Iter(1:100:end),recoverr_mead1(1:100:end),'b-','LineWidth',2);
hold on;
semilogy(Iter(1:100:end),recoverr_mead2(1:100:end),'r-','LineWidth',2);
hold on;
semilogy(Iter(1:100:end),recoverr_mead3(1:100:end),'k-','LineWidth',2);
xlabel('Iteration','FontSize',14);
ylabel('||x^k - x^*||','FontSize',14);
legend('ADMM','MEAD (\eta = 0.5)','MEAD (\eta = 1)','MEAD (\eta = 1.5)','FontSize',14);


% plot stationary error
figure(2),
semilogy(Iter(1:100:end),staterr_admm(1:100:end),'m-','LineWidth',2);
hold on;
semilogy(Iter(1:100:end),staterr_mead1(1:100:end),'b-','LineWidth',2);
hold on;
semilogy(Iter(1:100:end),staterr_mead2(1:100:end),'r-','LineWidth',2);
hold on;
semilogy(Iter(1:100:end),staterr_mead3(1:100:end),'k-','LineWidth',2);
xlabel('Iteration','FontSize',14);
ylabel('Stationary error','FontSize',14);
legend('ADMM','MEAD (\eta = 0.5)','MEAD (\eta = 1)','MEAD (\eta = 1.5)','FontSize',14);

% Iter = (1:NumIter)';
% % plot recovery error
% figure(1),
% semilogy(Iter,recoverr_admm,'m-','LineWidth',2);
% hold on;
% semilogy(Iter,recoverr_mead1,'b-','LineWidth',2);
% hold on;
% semilogy(Iter,recoverr_mead2,'r-','LineWidth',2);
% hold on;
% semilogy(Iter,recoverr_mead3,'k-','LineWidth',2);
% xlabel('Iteration','FontSize',14);
% ylabel('||x^k - x^*||','FontSize',14);
% legend('ADMM','MEAD (\eta = 0.5)','MEAD (\eta = 1)','MEAD (\eta = 1.5)','FontSize',14);
% % % axes('Position',[0.25,0.2,0.4,0.3]); % magnify the detailed figures
% % % plot(Iter(77:83),objfun1(77:83),'b-','LineWidth',2);
% % % hold on;
% % % plot(Iter(77:83),objfun2(77:83),'r-','LineWidth',2);
% % % hold on;
% % % plot(Iter(77:83),objfun3(77:83),'k-','LineWidth',2)
% % % axis([77,83,0,0.15]);
% 
% % plot stationary error
% figure(2),
% semilogy(Iter,staterr_admm,'m-','LineWidth',2);
% hold on;
% semilogy(Iter,staterr_mead1,'b-','LineWidth',2);
% hold on;
% semilogy(Iter,staterr_mead2,'r-','LineWidth',2);
% hold on;
% semilogy(Iter,staterr_mead3,'k-','LineWidth',2);
% xlabel('Iteration','FontSize',14);
% ylabel('Stationary error','FontSize',14);
% legend('ADMM','MEAD (\eta = 0.5)','MEAD (\eta = 1)','MEAD (\eta = 1.5)','FontSize',14);