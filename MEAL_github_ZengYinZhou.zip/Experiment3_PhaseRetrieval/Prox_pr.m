% proximal operator for the function f(x):= |<q,x>^2-p| used in phase retrieval
% Prox_gamma,f (z)=argmin_x {f(x)+||x-z||^2/(2gamma)}
function x = Prox_pr(q,p,gamma,z)
% input:
% q: data vector
% p: nonnegative data scalar
% gamma: proximal parameter
% z: current point

% define four candidates
xx = zeros(size(z,1),4);
xx(:,1) = z-q*(2*gamma*q'*z)/(2*gamma*norm(q)^2+1);
xx(:,2) = z-q*(2*gamma*q'*z)/(2*gamma*norm(q)^2-1);
xx(:,3) = z-q*(q'*z+sqrt(p))/norm(q)^2;
xx(:,4) = z-q*(q'*z-sqrt(p))/norm(q)^2;

y=zeros(4,1);
for i=1:4
   y(i)= proxfun(q,p,gamma,z,xx(:,i));
end
[~,I]=min(y);
x=xx(:,I(1)); % the proximal point is set as the candidate with the smalleset proximal objective
end

% define the proximal objective function
function y = proxfun(q,p,gamma,z,x)
y=abs((q'*x)^2-p)+norm(x-z)^2/2/gamma;
end